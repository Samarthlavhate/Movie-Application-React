import { Request,Response,NextFunction } from 'express'
import {MIDDLEWARE_CONSTANT} from '../temp/middleware_constant'


export class AuthGuard
{
    Authenticate(req:Request,res:Response,next:NextFunction):any{
    if(!req.headers.authorization){
        return res.send(401).send(MIDDLEWARE_CONSTANT.AUTHORIZATION)
    }
    const token =req.headers.authorization.split('Bearer')[1]
    if(token==null){
     return res.send(401).send(MIDDLEWARE_CONSTANT.AUTHORIZATION)
    }
    next()
    }
}
export default new AuthGuard()