export const MIDDLEWARE_CONSTANT={
    AUTHORIZATION:'Request is not authorized'
}