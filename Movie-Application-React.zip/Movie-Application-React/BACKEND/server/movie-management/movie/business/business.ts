import VideoeRepository from '../repository/repository'
import * as bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv'
import path from 'path'
dotenv.config({ path: path.join(__dirname, '../../../../.env') });
export class VideoBusiness {
    async addVideo(_req: any): Promise<any> {
        try {
            const user = await VideoeRepository.addVideo(_req)
            return Promise.resolve(user)
        } catch (e: any) {
            return Promise.reject(e)
        }
    }
    async getVideo(_req: any): Promise<any> {
        try {
            const user = await VideoeRepository.getVideo(_req)
            return  Promise.resolve(user)
        } catch (e: any) {
            return Promise.reject(e)
        }
    }
}

export default new VideoBusiness()