import express from 'express'
import VideoContoller from './controller/controller'
export default express.Router().
post('/add-video', VideoContoller.addVideo).
get('/get-video', VideoContoller.getVideo)