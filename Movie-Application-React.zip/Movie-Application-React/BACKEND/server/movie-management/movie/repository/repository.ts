import client from '../../../../db/db.config'
export class Videoepository {
    async addVideo(video: any): Promise<any> {
        try {
            const { youtubeLink, tags, Description, title } = video.body;
            const userId = video?.headers?.profileid
            const response = await client.query(
                `INSERT INTO videos (video_link, tags, description, title,created_at,created_by) VALUES ($1, $2, $3, $4, $5, $6)`,
                [youtubeLink, JSON.stringify(tags), Description, title, new Date(), userId]
            );
            return Promise.resolve(response)
        } catch (error) {
            return Promise.reject(error)
        }
    }
    async getVideo(video: any): Promise<any> {
        try {
            //   const userId=video?.headers?.profileid
            const response = await client.query(
                `SELECT * FROM videos`, []
            );
            return Promise.resolve(response)
        } catch (error) {
            return Promise.reject(error)
        }
    }
}

export default new Videoepository()