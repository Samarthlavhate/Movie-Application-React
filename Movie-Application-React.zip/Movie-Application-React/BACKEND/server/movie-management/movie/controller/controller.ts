
import VideoBusiness from '../business/business'
export class VideoContoller {
    async addVideo(_req: any, _res: any) {
        try {
            const user = await VideoBusiness.addVideo(_req)
            return  _res.json({code:'200',messgae:user})
        } catch (e: any) {
            return _res.json({code:'400',messgae:'Failed to create User'})
        }
    }
    async getVideo(_req: any, _res: any) {
        try {
            
            const user = await VideoBusiness.getVideo(_req)
            return  _res.json({code:'200',messgae:user})
        } catch (e: any) {
            return _res.json({code:'400',messgae:'Failed to create User'})
        }
    }
    
}

export default new VideoContoller()