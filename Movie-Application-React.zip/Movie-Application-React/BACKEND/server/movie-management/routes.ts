
import { AuthGuard } from "../common/middleware/auth_guard";
import {Application} from 'express'
import movie from './movie/routes'
import profile from './profile/routes'
const baseeUrl ='/api/v1/movie-management'
export default function routes(app:Application){
app.use(`${baseeUrl}/user`,profile);
app.use(`${baseeUrl}/movie`,movie)
}