
import ProfileBusiness from '../business/business'
export class ProfileContoller {
    async addUser(_req: any, _res: any) {
        try {
            console.log(_req)
            const user = await ProfileBusiness.addUser(_req.body)
            return  _res.json({code:'200',messgae:user})
        } catch (e: any) {
            return _res.json({code:'400',messgae:'Failed to create User'})
        }
    }
    async signInUser(_req: any, _res: any) {
        try {
            const user = await ProfileBusiness.signInUser(_req.body)
            return  _res.json({code:'200',message:user})
        } catch (e: any) {
            return _res.json({code:'400',message:'Failed to create User'})
        }
    }
}

export default new ProfileContoller()