import client from '../../../../db/db.config'
export class ProfileRepository {
    async addUser(req: any): Promise<any> {
        try {
            const values = [req.email, req.password, req.username];
            const response = await client.query(
                `INSERT INTO users (email, password, username) VALUES ($1, $2, $3)`,
                values
            );
           return Promise.resolve(response)
        } catch (e: any) {
            return Promise.reject(e)
        }
    }
   async  findUserByEmail(email: any): Promise<any> {
        try {const query = `SELECT * FROM users WHERE email = $1`;
            const values = [email];
            const response = await client.query(
                `SELECT * FROM users WHERE email = $1`,values
            );
           return  Promise.resolve(response)
        } catch (e: any) {
            return Promise.reject(e)
        }
    }
}

export default new ProfileRepository()