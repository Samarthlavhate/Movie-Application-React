import express from 'express'
import ProfileContoller from './controller/controller'
export default express.Router().post('/signup', ProfileContoller.addUser).
post('/login', ProfileContoller.signInUser)