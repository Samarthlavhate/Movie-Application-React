import ProfileRepository from '../repository/repository'
import * as bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv'
import path from 'path'
dotenv.config({ path: path.join(__dirname, '../../../../.env') });
export class ProfileBusiness {
    
    async hashPassword(password: string, saltRounds: number = 5): Promise<string> {
        const hash = await bcrypt.hash(password, saltRounds);
        return hash;
    }

    async comparePassword(password: string, hash: string): Promise<boolean> {
        const match = await bcrypt.compare(password, hash);
        return match;
    }
    async addUser(_req: any): Promise<any> {
        try {
            _req.password =await this.hashPassword(_req.password)
            const user = await ProfileRepository.addUser(_req)
           return Promise.resolve(user)
        } catch (e: any) {
            return Promise.reject(e)
        }
    }
    async signInUser(_req: any): Promise<any> {
        try {
            const { email, password } = _req;
            const user = await ProfileRepository.findUserByEmail(email);
            if (!user || !(await bcrypt.compare(password, user[0].password))) {
              throw new Error('Invalid email or password');
            }
            const token = jwt.sign({ userId: user.id }, process.env.SECRET_KEY, { expiresIn: '1h' });
            return { user:user[0], token };
          } catch (error) {
            return Promise.reject(error)
          }}
}

export default new ProfileBusiness()