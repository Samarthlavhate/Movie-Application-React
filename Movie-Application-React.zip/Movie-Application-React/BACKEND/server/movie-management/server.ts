import http from 'http'
import path from 'path'
import cookieParser from 'cookie-parser'
import bodyParser from 'body-parser'
import cors from 'cors'
import helmet from 'helmet'
import express, { Application } from 'express'
import dotenv from 'dotenv'
import PgConnection from '../../db/db.config'
const app = express()
dotenv.config({ path: path.join(__dirname, '../../.env') });
export default class MovieManagementServer {
    public routes: (app: Application) => void
    constructor() {
        PgConnection.connectDb()
        app.use(cors({ origin: '*' }))

        const root = path.normalize(__dirname + '/../..')
        app.use(express.json());
        app.use(bodyParser.urlencoded({
            extended: true,
            limit: process.env.LIMIT ?? '2mb'
        }))
        app.use(bodyParser
            .text({ limit: process.env.LIMIT ?? '2mb' }))
        app.use(cookieParser(process.env.SESSION_SECRET))
        app.use(express.static(`${root}/public`))
        app.use(helmet())
    }
    public router(routes: (app: Application) => void): this {
        routes(app)
        return this
    }

    listen(port: number): Application {
        http.createServer(app).listen(port, '0.0.0.0')
        console.info('up and running on port number ' + port)
        return app
    }
}