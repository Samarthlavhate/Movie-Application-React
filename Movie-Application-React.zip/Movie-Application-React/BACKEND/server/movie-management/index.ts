import MovieManagementServer from "./server"
import routes from './routes'
const port= parseInt(process.env.MOVIE_PORT??'5000')
export default new MovieManagementServer().router(routes).listen(port)