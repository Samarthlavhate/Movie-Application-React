/**
 * @type {import('node-pg-migrate').ColumnDefinitions | undefined}
 */
exports.shorthands = undefined;

/**
 * @param pgm {import('node-pg-migrate').MigrationBuilder}
 * @param run {() => void | undefined}
 * @returns {Promise<void> | void}
 */
exports.up = (pgm) => {
    pgm.createTable('videos', {
        id: 'serial PRIMARY KEY',
        video_link: 'text NOT NULL',
        tags: 'jsonb',
        description: 'text',
        title: 'text',
        created_at: 'timestamp DEFAULT NOW()',
        updated_at: 'timestamp DEFAULT NOW()',
        created_by: 'integer',
        updated_by: 'integer',
        deleted_at: 'timestamp',
        deleted_by: 'integer'
      });
    };    

/**
 * @param pgm {import('node-pg-migrate').MigrationBuilder}
 * @param run {() => void | undefined}
 * @returns {Promise<void> | void}
 */
exports.down = (pgm) => {
    pgm.dropTable('videos');
};
