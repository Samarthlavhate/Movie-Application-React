
echo 'Running sh script'
set -a
DATABASE_URL="postgres://postgres:password@localhost:5432/movie"
echo $DATABASE_URL
npm run migrate up --no-check-order