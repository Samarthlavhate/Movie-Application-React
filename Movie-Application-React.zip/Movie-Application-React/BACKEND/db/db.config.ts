import { Client, ClientConfig } from 'pg';
import dotenv from 'dotenv';
import path from 'path';
dotenv.config({ path: path.join(__dirname, '../.env') });

class PgConnection {
  private client: Client;

  constructor() {
    const config: ClientConfig = {
      user: process.env.DB_USER as string,
      host: process.env.DB_HOST as string,
      database: process.env.DB_NAME as string,
      password: process.env.DB_PASS as string,
      port: Number(process.env.DB_PORT), // Explicitly convert to number
    };

    this.client = new Client(config);
  }

  async connectDb(): Promise<void> {
    try {
      await this.client.connect();
      console.log('Connected to PostgreSQL database');
    } catch (err) {
      console.error('Error connecting to PostgreSQL database:', err.stack);
      process.exit(1); // Exit if the connection fails
    }
  }
  async query(queryText: string, values: any[]): Promise<any> {
    try {
      const result = await this.client.query(queryText,values);
      return result.rows;
    } catch (error) {
      console.error('Error executing query:', error);
      throw error;
    }
  }
}

export default new PgConnection();