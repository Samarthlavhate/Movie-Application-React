
setup project 

1. Set Up the PostgreSQL Database
Ensure you have a PostgreSQL database configured and running.
Add your database credentials to the .env file.


2. Run Database Migrations
Execute the migration command:
npm run migrate up --no-check-order
Confirm that all migrations have been applied successfully.


3. Start the Development Server
first do npm install
Spin up the server using:
npm run dev-movie




Deployment Strategy
Build the Docker Image

Build the Docker image using your preferred configuration.
Ensure the build completes successfully.
Push Docker Image to Amazon ECR

Upload the built Docker image to your Amazon Elastic Container Registry (ECR).
Deploy the Image to ECS

Deploy the Docker image from ECR to Amazon Elastic Container Service (ECS) using your CI/CD pipeline.
Confirm that the ECS service is up and running. 
