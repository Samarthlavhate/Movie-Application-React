
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';
import Login from './components/login/login.tsx'
import SignUp from './components/signup/signup.tsx'
import AddVideo from './components//addVideo/add-video.tsx'
import VideoList from './components/videoList/video-list.tsx';


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/add-video" element={<AddVideo />} />
        <Route path="/video-list" element={<VideoList />} />
      </Routes>
    </Router>
  );
}

export default App;
