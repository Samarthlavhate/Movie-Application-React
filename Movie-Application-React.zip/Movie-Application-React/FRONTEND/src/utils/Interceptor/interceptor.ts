import axios from 'axios'
import { Session } from 'inspector/promises'
const apiFunction = (url: string | undefined, port: string | undefined) => {
    const instance = axios.create({
        baseURL: `${url}:${Number
            (port)}`,
        headers: {
                'Content-Type': 'application/json'
        }
    })
    instance.interceptors.request.use(
        async (config: any) => {
            try {
                config.headers['profileId']=sessionStorage.getItem('userId')??9999
                config.headers['Authorization'] = `Bearer ${sessionStorage.getItem('token')}`
                return config
            } catch (error) {
                sessionStorage.clear()
                // await logout()
                return Promise.reject(error)
            }
        }
    )

    instance.interceptors.response.use(
        (res) => {
            return res
        },
        async (_err) => {
            Promise.reject(_err)
        }
    )
    return instance;
}

export default apiFunction