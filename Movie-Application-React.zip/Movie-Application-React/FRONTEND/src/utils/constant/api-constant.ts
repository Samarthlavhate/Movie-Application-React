const baseURL='api/v1/movie-management'

export const USERS={
    SIGNUP:`${baseURL}/user/signup`,
     LOGIN:`${baseURL}/user/login`
}
export const  VIDEOS_ACTION={
    ADD_VIDEO:`${baseURL}/movie/add-video`,
    VIDEO_LIST:`${baseURL}/movie/get-video`
}