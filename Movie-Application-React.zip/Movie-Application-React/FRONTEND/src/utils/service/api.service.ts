import apiFunction from '../Interceptor/interceptor.ts'
import { USERS,VIDEOS_ACTION } from '../constant/api-constant.ts'
const movieUrl:any = apiFunction(process.env.REACT_APP_BASE_URL, process.env.REACT_APP_PORT)

const userSignUp = (body: any) => {
    return movieUrl.post(`${USERS.SIGNUP}`, body)
}
const userLogIn=(body:any)=>{
   return movieUrl.post(`${USERS.LOGIN}`,body)
}
const addVideo=(body:any)=>{
    return movieUrl.post(`${VIDEOS_ACTION.ADD_VIDEO}`,body)
}
const fetchVideosList=()=>{
    return movieUrl.get(`${VIDEOS_ACTION.VIDEO_LIST}`)
}
export {
    userSignUp,
    userLogIn,
    addVideo,
    fetchVideosList
}