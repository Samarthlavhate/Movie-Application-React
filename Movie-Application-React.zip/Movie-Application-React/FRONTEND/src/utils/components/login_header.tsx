import React from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import './components.css'; // Import the CSS file
interface headerProps {
    headerName: string;
    navigateUrl: string;
    headerName2?:string
    navigate2?:string;
    clearSession?:boolean;
}
const Header = (props: headerProps) => {
    const { headerName, navigateUrl,clearSession,headerName2,navigate2 } = props
    const navigate = useNavigate()
    const handleRedirect = () => {
        if(clearSession){
            sessionStorage.clear()
        }
        navigate(navigateUrl)
    }
    const handleRedirectToAddPage=()=>{
        navigate(navigate2??'/')
    }
    return (
        <header className="header">
            <div className="logo">
                <span className="brand-name">Sierra</span>
            </div>
            <div className="right-section">
                <span className='' onClick={handleRedirectToAddPage}>{headerName2??''}&nbsp;&nbsp;</span>
                <span className="right-text" onClick={handleRedirect}>{headerName}</span>
            </div>
        </header>
    );
}

export default Header;