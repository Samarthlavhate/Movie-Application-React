import React, { useState,useEffect } from 'react';
import './video-list.css'
import Header from '../../utils/components/login_header.tsx';
import { fetchVideosList } from '../../utils/service/api.service.ts'
import Snackbar from '@mui/material/Snackbar';
import { Alert } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import ReactPlayer from 'react-player';

function VideoList() {
    const [videos, setVideos] = useState<any>([]);
  
    useEffect(() => {
      
      const fetchVideos = async () => {
        const fetchedVideos = await fetchVideosList(); 
        setVideos(fetchedVideos.data.messgae)
        console.log(fetchedVideos.data.messgae)
      };
  
      fetchVideos();
    }, []);
  
    return (
        <div style={{ height: '100%', backgroundColor: '#c58af9' }}>
      <Header headerName={'Log Out'} navigateUrl={'/'} clearSession={true} navigate2={'/add-video'} headerName2={'Add Video'} />
        <div className="video-list">
        {videos.map((video, index) => (
          <div className="video-card" key={index} style={{zIndex:'100'}} onClick={()=>console.log('sssss')}>
            <div className="video-thumbnail" onClick={()=>console.log('sssss')}>
              <iframe
                src={video.video_link.substring(0, video.video_link.lastIndexOf("/")) + "/preview"}
                width="300"
                onClick={()=>console.log('sssss')}
                height="200"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                title={video.title}
              />
              <div className="play-button">
                <i className="fa fa-play"></i>
              </div>
            </div>
            <div className="video-info">
              <h4>Title: {video.title}</h4>
              <p>Tags: #{video.tags.join(', #')}</p>
            </div>
          </div>
        ))}
      </div>  </div>
    );
  }
  
  export default VideoList;