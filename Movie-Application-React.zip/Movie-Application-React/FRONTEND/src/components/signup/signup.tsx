import React, { useState } from 'react';
import './signup.css';
import Header from '../../utils/components/login_header.tsx';
import { userSignUp } from '../../utils/service/api.service.ts'
import Snackbar from '@mui/material/Snackbar';
import { Alert } from '@mui/material';
import { useNavigate } from 'react-router-dom';


function Signup() {
  const [snackMsg, setSnackMsg] = useState<any>({
    message: '',
    severity: 'success'
  })
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    email: ''
  });
const navigate= useNavigate()
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response:any = await userSignUp(formData);
      if (response.data.code== 200) { 
        setSnackMsg({ message: 'User Created Successfully', severity: 'success' });
        navigate('/');
      } else {
        setSnackMsg({ message: 'Signup failed. Please check your details.', severity: 'error' });
      }
    } catch (error) {
      console.error('Signup error:', error);
      setSnackMsg({ message: 'Something went wrong. Please try again later.', severity: 'error' });
    }
  };

  return (

    <div style={{ height: '100vh', backgroundColor: '#c58af9' }}>
      <Header headerName={'Login'} navigateUrl={'/'} />
      <div className="signup-container">
        <div className="signup-content">
          <h2>Sign Up</h2>
          <form onSubmit={handleSubmit}>
            <div className="input-field">
              <label htmlFor="username">Username:</label>
              <input
                type="text"
                id="username"
                autoComplete="off"
                required
                name="username"
                value={formData.username}
                onChange={handleChange}
              />
            </div>
            <div className="input-field">
              <label htmlFor="email">email:</label>
              <input
                type="email"
                id="email"
                required
                autoComplete="off"
                name="email"
                value={formData.email}
                onChange={handleChange}
              />
            </div>
            <div className="input-field">
              <label htmlFor="password">Password:</label>
              <input
                type="password"
                autoComplete="off"
                id="password"
                required
                name="password"
                value={formData.password}
                onChange={handleChange}
              />
            </div>
            {/* Add more input fields as needed */}
            <button type="submit" className='signup-button'>Sign Up</button>
          </form>
        </div>
      </div>
      <Snackbar
        autoHideDuration={2000}
        sx={{zIndex:'1222'}}
        anchorOrigin={{ vertical: 'bottom', horizontal: "center" }}
        open={snackMsg?.message}
        onClose={() => setSnackMsg({ ...snackMsg, message: '' })}>
        <Alert
          onClose={() => setSnackMsg({ ...snackMsg, message: '' })}
          severity={snackMsg.severity}
        >{snackMsg?.message}</Alert>
      </Snackbar>
    </div>
  );
}

export default Signup;