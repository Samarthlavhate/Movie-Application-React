import React, { useState } from 'react';
import './login.css'
import Header from '../../utils/components/login_header.tsx';
import { userLogIn } from '../../utils/service/api.service.ts'
import Snackbar from '@mui/material/Snackbar';
import { Alert } from '@mui/material';
import { useNavigate } from 'react-router-dom';
const Login = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });
  const [snackMsg, setSnackMsg] = useState<any>({
    message: '',
    severity: 'success'
  })
  const navigate= useNavigate()
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response:any = await userLogIn(formData);
      if (response.data.code== 200) { 
        sessionStorage.setItem('token',response.data.message.token)
        sessionStorage.setItem('UserId',response.data.message.user.id)
        navigate('/video-list');
      } else {
        setSnackMsg({ message: 'Signup failed. Please check your details.', severity: 'error' });
      }
    } catch (error) {
      console.error('Signup error:', error);
      setSnackMsg({ message: 'Something went wrong. Please try again later.', severity: 'error' });
    }
  };

  return (
    <div style={{ height: '100vh', backgroundColor: '#c58af9' }}>
      <Header headerName={'Sign Up'} navigateUrl={'/signUp'} />
      <div className="login-container">

        <div className="login-content">
          <h2>Login</h2>
          <form onSubmit={handleSubmit}>
            <div className="input-field">
              <label htmlFor="email">User Email:</label>
              <input
                required
                autoComplete="off"
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
              />
            </div>
            <div className="input-field">
              <label htmlFor="password">Password:</label>
              <input
                required
                autoComplete="off"
                type="password"
                id="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
              />
            </div>
            <button type="submit" className='login-button'>Login</button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Login