import React, { useState } from 'react';
import './add-video.css'; // Assuming a CSS file for styling
import Header from '../../utils/components/login_header.tsx';

import Autocomplete from '@mui/material/Autocomplete';
import TextField from '@mui/material/TextField';
import { addVideo } from '../../utils/service/api.service.ts'

import { useNavigate } from 'react-router-dom';

function AddVideo() {
  const [formData, setFormData] = useState({
    youtubeLink: '',
    tags: [],
    Description: '',
    title: ''
  });
  const [snackMsg, setSnackMsg] = useState<any>({
    message: '',
    severity: 'success'
  })
  const navigate= useNavigate()
  const [selectedTags, setSelectedTags] = useState([]);

  const handleChange = (event) => {

    setFormData({
      ...formData,
      [event.target.name]: event.target.value,
    });
    console.log(formData)
  };

  const handleMultiSelectChange = (event, newValue) => {
    setFormData({
      ...formData,
      tags: newValue,
    });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const response =await addVideo(formData)
      if (response.data.code== 200) { 
        setSnackMsg({ message: 'Video Added Successfully', severity: 'success' });
        setFormData({ youtubeLink: '', tags: [], Description: '', title: '' });
        navigate('/video-list');
      } else {
        setSnackMsg({ message: 'Upload failed.', severity: 'error' });
      }
    } catch (error) {
      console.error('Signup error:', error);
      setSnackMsg({ message: 'Something went wrong. Please try again later.', severity: 'error' });
    }

  };

  return (
    <div className="sierra-container">
      <header className='position'>
        <Header headerName={'Log Out'} navigateUrl={'/'} clearSession={true} navigate2={'/video-list'} headerName2={'Videos'}  />
      </header>
      <main>
        <h1>Now Repurpose long video, 10x faster.</h1>
        <p>Sierra allows you to create new video content in just a few clicks, saving you time and effort.</p>
        <form onSubmit={handleSubmit}>
          <div className="input-field">
            <label htmlFor="youtubeLink">Paste your Video link</label>
            <input
              type="text"
              id="youtubeLink"
              name="youtubeLink"
              value={formData.youtubeLink}
              onChange={handleChange}
              required
            />
          </div>
          <div className="input-field">
            <label htmlFor="title">title</label>
            <input
              type="text"
              id="title"
              name="title"
              value={formData.title}
              onChange={handleChange}
              required
            />
          </div>
          <div className="input-field">
            <label htmlFor="Description">Description of the Video</label>
            <input
              type="text"
              id="Description"
              name="Description"
              value={formData.Description}
              onChange={handleChange}
              required
            />
          </div>
          <div className="input-field">
            <label htmlFor="tags">Video Tags</label>
            <Autocomplete
              multiple
              sx={{ backgroundColor: 'white', width: '104%' }}
              id="tags-outlined"
              onChange={handleMultiSelectChange}
              options={['Action', 'Comedy', 'Drama', 'WildLife']}
              getOptionLabel={(option) => option}
              filterSelectedOptions
              renderInput={(params) => (
                <TextField
                  {...params}
                  label=""
                  placeholder="Favorites"
                  sx={{ backgroundColor: 'white' }}
                />
              )}
              value={formData.tags} // Set the value to the selected tags
            />

          </div>
          <button className='button' type="submit">Call to Action</button>
        </form>
      </main>
    </div>
  );
}

export default AddVideo;